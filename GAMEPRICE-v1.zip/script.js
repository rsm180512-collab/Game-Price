const products = [
  {
    id: 1,
    name: "PlayStation 5 Slim",
    category: "Consolas",
    icon: "🎮",
    description: "Consola PS5 Slim con unidad de disco.",
    offers: [
      { store: "Tienda Gaming", price: 499.99, shipping: 0, url: "#" },
      { store: "MegaTech", price: 509.00, shipping: 0, url: "#" },
      { store: "GameShop", price: 519.99, shipping: 4.99, url: "#" }
    ]
  },
  {
    id: 2,
    name: "Nintendo Switch 2",
    category: "Consolas",
    icon: "🕹️",
    description: "Consola híbrida de nueva generación.",
    offers: [
      { store: "Tienda Gaming", price: 469.99, shipping: 0, url: "#" },
      { store: "MegaTech", price: 479.00, shipping: 0, url: "#" },
      { store: "GameShop", price: 489.99, shipping: 5.99, url: "#" }
    ]
  },
  {
    id: 3,
    name: "GeForce RTX 5070",
    category: "Componentes",
    icon: "🖥️",
    description: "Tarjeta gráfica gaming de alto rendimiento.",
    offers: [
      { store: "MegaTech", price: 649.00, shipping: 0, url: "#" },
      { store: "Tienda Gaming", price: 659.00, shipping: 0, url: "#" },
      { store: "GameShop", price: 639.00, shipping: 12.99, url: "#" }
    ]
  },
  {
    id: 4,
    name: "Logitech G Pro X 2",
    category: "Audio",
    icon: "🎧",
    description: "Auriculares inalámbricos para gaming.",
    offers: [
      { store: "GameShop", price: 179.99, shipping: 0, url: "#" },
      { store: "MegaTech", price: 189.00, shipping: 0, url: "#" },
      { store: "Tienda Gaming", price: 199.99, shipping: 4.99, url: "#" }
    ]
  },
  {
    id: 5,
    name: "Razer BlackWidow V4",
    category: "Periféricos",
    icon: "⌨️",
    description: "Teclado mecánico gaming.",
    offers: [
      { store: "MegaTech", price: 139.99, shipping: 0, url: "#" },
      { store: "GameShop", price: 145.00, shipping: 0, url: "#" },
      { store: "Tienda Gaming", price: 149.99, shipping: 5.99, url: "#" }
    ]
  },
  {
    id: 6,
    name: "EA Sports FC 26",
    category: "Videojuegos",
    icon: "⚽",
    description: "Videojuego de fútbol para consola.",
    offers: [
      { store: "GameShop", price: 59.99, shipping: 0, url: "#" },
      { store: "Tienda Gaming", price: 64.99, shipping: 0, url: "#" },
      { store: "MegaTech", price: 69.99, shipping: 3.99, url: "#" }
    ]
  }
];

const categories = [
  ["🎮", "Consolas"],
  ["🎯", "Videojuegos"],
  ["🖥️", "Componentes"],
  ["🎧", "Audio"],
  ["⌨️", "Periféricos"],
  ["💻", "PC Gaming"]
];

const productGrid = document.getElementById("productGrid");
const categoryGrid = document.getElementById("categoryGrid");
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchMessage = document.getElementById("searchMessage");
const resultsTitle = document.getElementById("resultsTitle");
const clearFilter = document.getElementById("clearFilter");
const noResults = document.getElementById("noResults");
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");

const money = value => new Intl.NumberFormat("es-ES", {
  style: "currency",
  currency: "EUR"
}).format(value);

function total(offer) {
  return offer.price + offer.shipping;
}

function bestOffer(product) {
  return [...product.offers].sort((a, b) => total(a) - total(b))[0];
}

function renderCategories(active = "") {
  categoryGrid.innerHTML = categories.map(([emoji, name]) => `
    <button class="category ${active === name ? "active" : ""}" data-category="${name}">
      <span class="emoji">${emoji}</span>
      <strong>${name}</strong>
    </button>
  `).join("");

  categoryGrid.querySelectorAll(".category").forEach(btn => {
    btn.addEventListener("click", () => filterCategory(btn.dataset.category));
  });
}

function renderProducts(list) {
  productGrid.innerHTML = list.map(product => {
    const best = bestOffer(product);
    return `
      <article class="product-card">
        <div class="product-image">${product.icon}</div>
        <div class="product-info">
          <div class="product-category">${product.category}</div>
          <h3>${product.name}</h3>
          <p>${product.description}</p>
          <div class="best-price">
            <div>
              <small>Desde</small>
              <div class="price">${money(total(best))}</div>
              <small>${best.store}</small>
            </div>
            <button class="buy-button" data-product="${product.id}">Comparar</button>
          </div>
        </div>
      </article>
    `;
  }).join("");

  productGrid.querySelectorAll(".buy-button").forEach(btn => {
    btn.addEventListener("click", () => openProduct(Number(btn.dataset.product)));
  });
  noResults.classList.toggle("hidden", list.length !== 0);
}

function filterCategory(category) {
  const filtered = products.filter(p => p.category === category);
  resultsTitle.textContent = category;
  clearFilter.classList.remove("hidden");
  searchMessage.textContent = `${filtered.length} producto(s) encontrado(s).`;
  renderCategories(category);
  renderProducts(filtered);
  document.getElementById("productos").scrollIntoView({ behavior: "smooth" });
}

function searchProducts(query) {
  const q = query.trim().toLowerCase();
  if (!q) {
    resultsTitle.textContent = "Productos destacados";
    clearFilter.classList.add("hidden");
    searchMessage.textContent = "";
    renderCategories();
    renderProducts(products);
    return;
  }

  const filtered = products.filter(p =>
    `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q)
  );

  resultsTitle.textContent = `Resultados para "${query.trim()}"`;
  clearFilter.classList.remove("hidden");
  searchMessage.textContent = `${filtered.length} producto(s) encontrado(s).`;
  renderCategories();
  renderProducts(filtered);
  document.getElementById("productos").scrollIntoView({ behavior: "smooth" });
}

function openProduct(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;

  const offers = [...product.offers].sort((a, b) => total(a) - total(b));
  const best = offers[0];

  modalBody.innerHTML = `
    <p class="eyebrow">${product.category}</p>
    <h2 id="modalTitle">${product.icon} ${product.name}</h2>
    <p style="color:var(--muted);line-height:1.6">${product.description}</p>
    <div class="offer-list">
      ${offers.map((offer, index) => `
        <div class="offer">
          <div>
            <div class="offer-store">${offer.store} ${index === 0 ? "⭐" : ""}</div>
            <small>Envío: ${offer.shipping === 0 ? "Gratis" : money(offer.shipping)}</small>
          </div>
          <div class="offer-price">${money(total(offer))}</div>
          <a class="buy-button" href="${offer.url}" target="_blank" rel="noopener noreferrer">Ver oferta</a>
        </div>
      `).join("")}
    </div>
    <p style="color:var(--muted);font-size:12px;margin-top:20px">
      Oferta destacada: ${best.store}. Los precios mostrados son datos de demostración.
    </p>
  `;

  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
}

searchForm.addEventListener("submit", event => {
  event.preventDefault();
  searchProducts(searchInput.value);
});

clearFilter.addEventListener("click", () => {
  searchInput.value = "";
  searchProducts("");
});

document.querySelectorAll("[data-close-modal]").forEach(el => {
  el.addEventListener("click", closeModal);
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});

renderCategories();
renderProducts(products);
