# GAMEPRICE — primera versión

## Qué incluye

- Página de inicio responsive.
- Buscador de productos.
- Categorías.
- Comparación de ofertas por producto.
- Cálculo del precio total incluyendo envío.
- Ventana de comparación.
- Diseño preparado para móvil.

## Importante

Los productos, precios y tiendas incluidos son SOLO DATOS DE DEMOSTRACIÓN.
Antes de publicar ofertas reales, sustituye esos datos por información que puedas utilizar legítimamente y enlaces reales de las tiendas o de programas de afiliados.

## Publicación gratuita con GitHub Pages

1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo, por ejemplo: `gameprice`.
3. Sube `index.html`, `style.css` y `script.js`.
4. En el repositorio entra en Settings > Pages.
5. Selecciona "Deploy from a branch".
6. Elige la rama `main` y la carpeta `/ (root)`.
7. Guarda.
8. GitHub te proporcionará una dirección pública para la web.

## Dónde cambiar los productos

Abre `script.js`.

Al principio del archivo encontrarás:

const products = [...]

Ahí puedes cambiar nombres, categorías, precios, tiendas y enlaces.

## Próximo paso recomendado

Cuando esta versión esté publicada, el siguiente salto es crear una base de datos y conectar fuentes de productos/precios para que GAMEPRICE no dependa de introducir cada oferta manualmente.
